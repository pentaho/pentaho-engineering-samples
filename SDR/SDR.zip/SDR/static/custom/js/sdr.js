var SDR = {};

SDR.newString = function f(value){
    
    var SEPARATOR = ";";
    
    if (_.isArray(value)){
        value = value.join(SEPARATOR);
    }

    return value;
};


SDR.getPUC = function ( methodName, frame ) {
	if ( frame === undefined ) {
		return undefined; 
	}

	// if this frame has the method then assume this is the PUC frame
	if ( frame[methodName] !== undefined ) {
		return frame[methodName];
	}

	// if reached topmost frame and did not find method
	if ( frame.parent === frame ) {
		return undefined;
	}
	// else search ancestors
	else {
		return SDR.getPUC( methodName, frame.parent );
	}
};



SDR.openAnalyzer = function (datasource){

    var popupComponent = Dashboards.getComponentByName('render_processingPopup'),
		inputComponent = Dashboards.getComponentByName('render_dataSourceTextComponent');
		
	inputComponent.placeholder('input').val("");
	//gotoAnalyzer = Dashboards.getParameterValue('analyzerParam')[0];

	//Cleanup 
	$('#popupComponentOverlay').removeClass('popupOverlay');
    popupComponent.hide();
	
	//Call analyzer
//	datasource = undefined;
    var catalog = datasource, // || "SampleData", 
        cube = catalog;
		
//    cube = datasource ? cube : 'Quadrant Analysis';
	
	//Verify if we are inside PUC
	
	var pucOpenTab = SDR.getPUC( 'mantle_openTab', window );
	var url = [
                Dashboards.getWebAppPath(),
                '/api/repos/xanalyzer/editor', '?',
                'showFieldList=true', '&',
                'showFieldLayout=true', '&',
                'catalog=', encodeURI(catalog), '&',
                'cube=', encodeURI(cube), '&',
                'autoRefresh=true', '&',
                'fieldListView=cmdViewCategory'
        ].join('');
 
 
	//Verify if we are inside PUC
	if ( pucOpenTab ) {
			var name = "Analysis Report",
				title = "Movie Ratings - SDR Sample";
			pucOpenTab( name, title, url );
	}
	else {
			url = [ url, '&showRepositoryButtons=true' ].join('');
			window.open( url );
	}

	/*
	if (window.top.mantle_openTab == undefined){
		window.open([
			Dashboards.getWebAppPath(),
			'/api/repos/xanalyzer/editor?showFieldList=true&showFieldLayout=true&',
			"catalog=", escape(catalog), "&",
			"cube=", escape(cube), "&",
			'autoRefresh=true&showRepositoryButtons=',
			'&fieldListView=cmdViewType',
			'&showRepositoryButtons=true'
			].join('')
		);
	}else{
		var name = "Analysis Report",
			title = "Movie Ratings - SDR Sample",
			url = [
				Dashboards.getWebAppPath(),
				'/api/repos/xanalyzer/editor?showFieldList=true&showFieldLayout=true&',
				"catalog=", escape(catalog), "&",
				"cube=", escape(cube), "&",
				'autoRefresh=true&showRepositoryButtons=',
				'&fieldListView=cmdViewType'
			].join('')
		
		window.top.mantle_openTab(name, title, url);
	}
	*/


}