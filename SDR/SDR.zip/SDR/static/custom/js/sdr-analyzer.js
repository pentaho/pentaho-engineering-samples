/**
 * We start by registering SDR as a plugin available on Analyzer. This will call the init function of the SDR.
 * When 
 */


/**
 * Registering SDR as a plugin of analyzer, and init SDR javascript code when initializing analyzer.
 */
var analyzerPlugins = analyzerPlugins || []; 
analyzerPlugins.push( 
    { 
      init:function () {
          require(['SDR'], function(SDR) {
              SDR.init()
          });
      }
    }
);

/**
 * Create a namespace for SDR plugin javascript code to use inside analyzer 
 */
define ('SDR', [], function() {

    var self = {};

    self.windowContext = undefined;
    self.promoteDialog = undefined;

    self.baserver = {};
    self.baserver.api = {
        hasDataAccess:   'plugin/data-access/api/permissions/hasDataAccess',
        acl:             'plugin/data-access/api/datasource/dsw/${datasource}/acl',
        userRoles:       'api/userroledao/userRoles?userName=${username}',
        lookupXmiId:     'api/repos/xanalyzer/service/ajax/lookupXmiId'
    };

    self.aces = {
      xml:         '<aces>'+
                       '<modifiable>false</modifiable>'+
                       '<recipient>{recipient}</recipient>'+
                       '<recipientType>{recipientType}</recipientType>'+
                       '<permissions>{permission}</permissions>'+
                   '</aces>'
    },
    self.ui = {};
    self.ui.ids = {
        toolbar:   'main_toolbar',
        button:    'sdr-cmdChangeDatasourcePermissionButton',
        separator: 'sdr-cmdChangeDatasourcePermissionSeparator',
        popupBox:  'sdr-confirmationPopup'
    };

    self.ui.html = {
        separator: '<div class="separator" id="'+self.ui.ids.separator+'"></div>',

        promote:   '<div class="reportBtn sdr-promote-datasource" id="'+self.ui.ids.button+'">'+
                       'Promote datasource to '+
                       '<span class="sdr-promoteDatasource sdr-promoteToMygroup">My Groups</span>'+
                       '<span class="sdr-promoteToSeparator"> or </span>'+
                       '<span class="sdr-promoteDatasource sdr-promoteToAuthenticated">Everyone</span>'+
                   '</div>',
        popupBox:  '<div class="sdr-pentaho-dialog" id="'+self.ui.ids.popup+'"">'+
                        '<table>'+
                            '<tbody>'+
                                '<tr class="dialogMiddle">'+
                                    '<td class="dialogMiddleCenter">'+
                                        '<div class="popupHeader Caption" id=popupHeader>Data Source Permissions will be changed.</div>'+
                                        '<div class="dialog-content">'+
                                            '<div class="popupText gwt-Label" id=popupText><p>You are about to make the Data Source available for <b>{recipient}</b>.</p><p>&nbsp</p><p>&nbsp</p></div>'+
                                            '<div class="popupButtons button-panel" id="popupButtons">'+
                                                '<button type="button" class="pentaho-button sdr-confirmButton" id="sdr-confirmButton">Proceed</button>'+
                                                '<button type="button" class="pentaho-button sdr-cancelButton" id="sdr-cancelButton">Cancel</button>'+
                                            '</div>'+
                                        '</div>'+
                                    '</td>'+
                                '</tr>'+
                            '</tbody>'+
                        '</table>'+
                    '</div>'
    };

    /**
     * get iframe context if we are on a tab inside PUC
     */
    self.getPUC = function( methodName, frame ) {
        if ( frame === undefined ) {
            return undefined; 
        }
        // if this frame has the method then assume this is the PUC frame
        if ( frame[methodName] !== undefined ) {
            return frame;
        }
        // if reached topmost frame and did not find method
        if ( frame.parent === frame ) {
            return undefined;
        }
        // else search ancestors
        else {
            return self.getPUC( methodName, frame.parent );
        }
    };

    /**
     * Verify if we are inside an iframe or window and get context.
     */
    self.getWindowContext = function( ) {
        var tab = self.getPUC('mantle_openTab', window);
        self.windowContext =  (tab ? tab : window);
    };
    
    /**
     * Verify the datasource ACL and add elements if is not public
     */
    self.verifyDatasourceACL = function( ) {
        var datasourceName = self.getDatasourceName();
        var sucessCallback = function(data) {
            var $aces = $(data).find('aces'),
                isPromotedToEveryone = self.isPromotedToEveryone($aces);
            if (!isPromotedToEveryone) {
                self.appendButton( );  
            }
        };
        self.getDatasourceACL(datasourceName, sucessCallback);
    };

    /**
     * Check if datasource is already public.
     */
    self.isPromotedToEveryone = function($aces) {
        var privateDatasource = false;
        $aces.each(function(idx, elem) {
            if (($(elem).find('recipient').text() == 'Authenticated') &&
                ($(elem).find('recipientType').text() == '1') && 
                ($(elem).find('modifiable').text() == 'true')) {
                privateDatasource = true;
            }
        });
        return privateDatasource;
    };

    /**
      * Check if datasource is promoted to mygroups 
     */
    self.isPromotedToMygroups = function($aces) {
        var privateDatasource = false;
        $aces.each(function(idx, elem) {
            if (($(elem).find('recipient').text() == 'Authenticated') &&
                ($(elem).find('recipientType').text() == '1') && 
                ($(elem).find('modifiable').text() == 'true')) {
                privateDatasource = true;
            }
        });
        return privateDatasource;
    };

    /**
     * Append a button to the analyzer space and bind events. It will fire a dialog with the options inside.
     */
    self.removePromoteToEveryone = function(  ) {
        var $toolbar = $('#'+self.ui.ids.toolbar); 
        $toolbar.find('#'+self.ui.ids.separator).remove();
        $toolbar.find('#'+self.ui.ids.button).remove();
    }

    /**
     * Append a button to the analyzer space and bind events. It will fire a dialog with the options inside.
     */
    self.removePromoteToMygroups = function(  ) {
        var $toolbar = $('#'+self.ui.ids.toolbar);
        var $promote = $toolbar.find('.sdr-promote-datasource');
        $promote.find('.sdr-promoteToMygroup').remove();
        $promote.find('.sdr-promoteToSeparator').remove();
    }

    /**
     * Append a button to the analyzer space and bind events. It will fire a dialog with the options inside.
     */
    self.appendButton = function( ) {
        var $toolbar = $('#'+self.ui.ids.toolbar); 
        var $separator = $(self.ui.html.separator);
        var $promote = $(self.ui.html.promote);
       
        var datasourceName = self.getDatasourceName();
        $toolbar.append($separator).append($promote);

        $promote.find('.sdr-promoteToMygroup').on('click', function() {
            var username = SESSION_NAME;
            var roles = self.getUserRoles(username);
            self.openConfirmationDialog('My Groups', datasourceName, roles, '1', '4', true, self.removePromoteToMygroups);
        });
        $promote.find('.sdr-promoteToAuthenticated').on('click', function() {
            self.openConfirmationDialog('Everyone', datasourceName, ['Authenticated'], '1', '4', true, self.removePromoteToEveryone);
        });
    };


    /**
     * Append a button to the analyzer space and bind events. It will fire a dialog with the options inside.
     */
    self.openConfirmationDialog = function(recipient, datasourceName, recipientsArray, recipientType, permissions, overwrite, callback ) {
        var $popupBox = $(self.ui.html.popupBox);
        var $recipient = $popupBox.find('.popupText b')
        $recipient.text($recipient.text().replace('{recipient}', recipient));
        $popupBox.find('.sdr-confirmButton').on('click', function() {
            self.setDatasourceACL(datasourceName, recipientsArray, recipientType, permissions, overwrite); 
            if ($.isFunction(callback)) {
                callback();
            }
            self.promoteDialog.hide();
        });
        $popupBox.find('.sdr-cancelButton').on('click', function() {
            self.promoteDialog.hide();
        });
        self.promoteDialog = new dijit.Dialog({
            title: "Promote Datasource",
            content: $popupBox
        });
        self.promoteDialog.show();
    };



    /**
     * Call an endpoint to verify if the current user have access to change datasources
     * * @param {String} recipient: the recipient id, user or role
     */
    self.hasDataAccess = function() {
        var successCallback = function(hasDataAccess) {
            if (hasDataAccess) {
                self.verifyDatasourceACL();
            }
        };
        var settings = {type: 'GET', success: successCallback};
        self.ajaxRequest(self.baserver.api.hasDataAccess, settings);
    };

    /**
     * Call an endpoint to get the acl for a particular datasource wizard
     * @param {String} datasourceName: name of the datasource without .xmi extension 
     * @param {Function} succesCallback: function to execute in case of success
     */
    self.getDatasourceACL = function(datasourceName, successCallback) {
        var settings = {type: 'GET', success: successCallback};
        self.ajaxRequest(self.baserver.api.acl.replace('${datasource}', datasourceName), settings);
    };

    /**
     * Call an endpoint to set the acl for a particular datasource wizard
     * @param {String} datasourceName: name of the datasource without .xmi extension 
     * @param {String} recipient: the recipient id, user or role
     * @param {String} recipientType: 0 for user and 1 for role
     * @param {String} permission: 0, 1, 2, 3 or 4 depending on permission to set
     * @param {Boolean} overwrite: true or false to overwrite or not the permissions
     */
    self.setDatasourceACL = function(datasourceName, recipientsArray, recipientType, permission, overwrite) {
        self.getDatasourceACL(datasourceName, function(data){
            if (recipientsArray.length > 0) {
              var $currentACL = $(data);
              if (overwrite) {
                  $currentACL.find('repositoryFileAclDto').find('aces').remove();
              }
              $(recipientsArray).each(function(idx, elem) {
                  var newACES = self.aces.xml;
                  newACES = newACES.replace('{recipient}', elem).replace('{recipientType}', recipientType).replace('{permission}', permission);  
                  $currentACL.find('repositoryFileAclDto').prepend($($.parseXML(newACES)).find('aces'));       
              });
            }
            var settings = {type: "PUT", contentType: 'application/xml', data: self.xmlToString($currentACL)};
            self.ajaxRequest(self.baserver.api.acl.replace('${datasource}', datasourceName), settings);
        });
    };

    /**
     * Call an endpoint to get the user roles list
     * @username {String} [Username]
     * @return {Array} [Array with the roles which the user belongs to]
     */
    self.getUserRoles = function(username) {
        var roles = [];
        var successCallback = function(data) {
            $(data).find('roles').each(function(idx, elem) {
                roles.push($(elem).text());
            });    
        };
        var settings = {type: 'GET', async: false, success: successCallback};
        self.ajaxRequest(self.baserver.api.userRoles.replace('${username}', username), settings);
        return roles;
    }

    /**
     * Call an endpoint to get XMI ID based on 
     * @return {Array} [Array with the roles which the user belongs to]
     */
    self.getDatasourceName = function() {
        //var catalog = self.windowContext.cv.getActiveReport().catalog;
        //var cube = self.windowContext.cv.getActiveReport().cube;
        var catalog = window.cv.getActiveReport().catalog;
        var cube = window.cv.getActiveReport().cube;

        var datasourceName = "";
        var successCallback = function(data) {
            datasourceName = data;
        };
        var data = {
            catalog: catalog,
            cube: cube
        }
        var settings = {type: 'POST', async: false, data: data, success: successCallback};
        self.ajaxRequest(self.baserver.api.lookupXmiId, settings);
        return datasourceName;
    }

    /**
     * Make an ajax request to the server
     * @endpoint {String} endpoint: endpoint excluding protocol, server, port and web app context
     * @param {String} settings: the settings of the request to send 
     */
    self.ajaxRequest = function(endpoint, settings) {
        var contextPath = CONTEXT_PATH;
        var url = contextPath + endpoint;
        $.ajax(url, settings);
    };

    /**
     * Convert xml to string 
     */
    self.xmlToString = function($xml) {
        var xmlString = "";
        if (window.ActiveXObject){ 
            xmlString = $xml.xml; 
        } else {
            var oSerializer = new XMLSerializer(); 
            xmlString = oSerializer.serializeToString($xml[0]);
        }
        return xmlString; 
    };
    
    /**
     * Called when the analyzer pluing is initiated
     */
    self.init = function() {
        self.getWindowContext();
        self.hasDataAccess();
        
    };

    return self;
});